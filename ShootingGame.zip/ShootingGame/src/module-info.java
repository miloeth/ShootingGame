/**
 * 
 */
/**
 * 
// */
//module game2DPlatform {
//	requires java.desktop;
//}