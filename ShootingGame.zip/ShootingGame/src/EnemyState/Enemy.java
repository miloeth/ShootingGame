package EnemyState;

import java.awt.Graphics2D;

import Entity.Entity;
import main.GamePanel;
import main.KeyHandler;

public class Enemy extends Entity {
	public Enemy(GamePanel gp, KeyHandler keyH) {
		super(gp, keyH);
	}
	public void update() {
		
	}
	public void draw(Graphics2D g2) {
		
	}
	public void getDamaged() {
	}
}
