//package Skill;
//
//import main.GamePanel;
//
//public class SkillManager {
//	public static SkillManager instance;
//	private GamePanel gp;
//	public SkillManager(GamePanel gp) {
//		this.gp=gp;
//		start();
//	}
//	public void start() {
//		instance=this;
//	}
//}
